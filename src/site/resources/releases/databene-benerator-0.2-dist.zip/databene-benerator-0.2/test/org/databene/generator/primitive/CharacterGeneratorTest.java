package org.databene.generator.primitive;

import junit.framework.TestCase;
import org.databene.generator.GeneratorTestSupport;
import org.databene.commons.ArrayUtil;

import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 09.06.2006 21:03:42
 */
public class CharacterGeneratorTest extends TestCase {

    public void testDefaultConstructor() {
        new CharacterGenerator();
    }

    public void testDigit() throws Exception {
        GeneratorTestSupport.checkProductSet(new CharacterGenerator("\\d"), 1000,
                ArrayUtil.asSet('0', '1', '2', '3', '4', '5', '6', '7','8', '9'));
    }

    public void testRange() throws Exception {
        GeneratorTestSupport.checkProductSet(new CharacterGenerator("[1-2]"), 1000, ArrayUtil.asSet('1', '2'));
        GeneratorTestSupport.checkProductSet(new CharacterGenerator("[12]"), 1000, ArrayUtil.asSet('1', '2'));
    }

    public void testLocale() throws Exception {
        HashSet<Character> expectedSet = new HashSet<Character>();
        for (char c = 'A'; c <= 'Z'; c++)
            expectedSet.add(c);
        for (char c = 'a'; c <= 'z'; c++)
            expectedSet.add(c);
        for (char c = '0'; c <= '9'; c++)
            expectedSet.add(c);
        expectedSet.add('_');
        expectedSet.add('�');
        expectedSet.add('�');
        expectedSet.add('�');
        expectedSet.add('�');
        expectedSet.add('�');
        expectedSet.add('�');
        expectedSet.add('�');

        GeneratorTestSupport.checkProductSet(new CharacterGenerator("\\w", Locale.GERMAN), 10000, expectedSet);
    }

    public void testSet() {
        Set<Character> values = ArrayUtil.asSet('A', 'B');
        GeneratorTestSupport.checkProductSet(new CharacterGenerator(values), 1000, values);
    }
}
