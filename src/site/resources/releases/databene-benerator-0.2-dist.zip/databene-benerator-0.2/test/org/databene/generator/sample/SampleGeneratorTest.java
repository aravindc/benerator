package org.databene.generator.sample;

import junit.framework.TestCase;

import org.databene.generator.sample.SampleGenerator;
import org.databene.generator.sample.Sample;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 07.06.2006 21:59:02
 */
public class SampleGeneratorTest extends TestCase {

    private static Log logger = LogFactory.getLog(SampleGeneratorTest.class);

    public void testInstantiation() throws Exception {
        new SampleGenerator<Integer>();
        new SampleGenerator<String>();
    }

    public void testDistribution() throws Exception {
        Sample<Integer>[] samples = new Sample[] {
            new Sample<Integer>(0, 0.1),
            new Sample<Integer>(1, 0.3),
            new Sample<Integer>(2, 0.6)
        };
        SampleGenerator<Integer> g = new SampleGenerator<Integer>();
        g.setSamples(samples);
        int n = 10000;
        int[] sampleCount = new int[3];
        for (int i = 0; i < n; i++) {
            sampleCount[g.generate()] ++;
        }
        List<Sample<Integer>> samples2 = g.getSamples();
        for (int i = 0; i < sampleCount.length; i++) {
            int count = sampleCount[i];
            double measuredProbability = (float)count / n;
            double expectedProbability = samples2.get(i).getWeight();
            double ratio = measuredProbability / expectedProbability;
            logger.debug(i + " " + count + " " + ratio);
            assertTrue(ratio > 0.9 && ratio < 1.1);
        }
    }
}
