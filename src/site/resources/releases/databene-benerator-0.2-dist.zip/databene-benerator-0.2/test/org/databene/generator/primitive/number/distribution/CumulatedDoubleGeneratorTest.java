package org.databene.generator.primitive.number.distribution;

import junit.framework.TestCase;
import org.databene.generator.GeneratorTestSupport;
import org.databene.commons.ArrayUtil;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 07.06.2006 20:23:39
 */
public class CumulatedDoubleGeneratorTest extends TestCase {

    public void testSingle() {
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator( 0,  0), 100, ArrayUtil.asSet( 0.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator(-1, -1), 100, ArrayUtil.asSet(-1.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator( 1,  1), 100, ArrayUtil.asSet( 1.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator( 1,  1, 1), 100, ArrayUtil.asSet(1.));
    }

    public void testRange() {
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator( 0,  1, 1), 1000, ArrayUtil.asSet( 0.,  1.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator( 1,  2, 1), 1000, ArrayUtil.asSet( 1.,  2.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator(-2, -1, 1), 1000, ArrayUtil.asSet(-2., -1.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator(-1,  0, 1), 1000, ArrayUtil.asSet(-1.,  0.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator(-1,  1, 1), 1000, ArrayUtil.asSet(-1.,  0., 1.));
    }

    public void testPrecision() {
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator( 1,  3, 2), 100, ArrayUtil.asSet( 1.,  3.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator(-3, -1, 2), 100, ArrayUtil.asSet(-3., -1.));
        GeneratorTestSupport.checkProductSet(new CumulatedDoubleGenerator(-1,  1, 2), 100, ArrayUtil.asSet(-1.,  1.));
    }
}
