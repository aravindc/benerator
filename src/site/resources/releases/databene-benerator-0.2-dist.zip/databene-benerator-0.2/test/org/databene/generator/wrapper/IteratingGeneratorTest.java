/*
 * (c) Copyright 2006 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.generator.wrapper;

import junit.framework.TestCase;
import org.databene.generator.*;
import org.databene.commons.ArrayUtil;

/**
 * Created: 11.10.2006 23:10:34
 */
public class IteratingGeneratorTest extends TestCase {

    public void testOneElementRepetitive() {
        ConstantTestGenerator<Integer> source = new ConstantTestGenerator<Integer>(1);
        IteratingGenerator<Integer> generator = new IteratingGenerator<Integer>(source, Iteration.REPETITIVE);
        GeneratorTestSupport.checkProductSet(generator, 100, ArrayUtil.asSet(1));
    }

    public void testRepetitive() {
        SequenceTestGenerator<Integer> source = new SequenceTestGenerator<Integer>(1, 2);
        IteratingGenerator<Integer> generator = new IteratingGenerator<Integer>(source, Iteration.REPETITIVE);
        assertEquals(1, (int)generator.generate());
        assertEquals(2, (int)generator.generate());
        assertEquals(1, (int)generator.generate());
    }

    public void testSkip() {
        SequenceTestGenerator<Integer> source = new SequenceTestGenerator<Integer>(1, 2, 3);
        IteratingGenerator<Integer> generator = new IteratingGenerator<Integer>(source, Iteration.REPETITIVE, 1, 2);
        int value = generator.generate();
        assertTrue(value == 1 || value == 2);
    }

    public void testNonRepetitive() {
        SequenceTestGenerator<Integer> source = new SequenceTestGenerator<Integer>(1, 2);
        IteratingGenerator<Integer> generator = new IteratingGenerator<Integer>(source, Iteration.SINGLE);
        assertEquals(1, (int)generator.generate());
        assertEquals(2, (int)generator.generate());
        try {
            generator.generate();
            fail("IllegalGeneratorStateException expected");
        } catch (IllegalGeneratorStateException e) {
            // expected
        }
    }

    public void testInvalidSetup() {
        Generator<Integer> source = new ConstantTestGenerator<Integer>(1);
        checkInvalidSetup(null, Iteration.REPETITIVE, 1, 1);
        checkInvalidSetup(source, null, 1, 1);
        checkInvalidSetup(source, Iteration.REPETITIVE, -1, 1);
        checkInvalidSetup(source, Iteration.REPETITIVE, 1, -1);
    }

    private void checkInvalidSetup(Generator<Integer> source, Iteration iteration, int minIncrement, int maxIncrement) {
        try {
            IteratingGenerator generator = new IteratingGenerator<Integer>(source, iteration, minIncrement, maxIncrement);
            generator.validate();
            fail("InvalidGeneratorSetupException expected");
        } catch (InvalidGeneratorSetupException e) {
            // this is the expected behavior
        }
    }
}
