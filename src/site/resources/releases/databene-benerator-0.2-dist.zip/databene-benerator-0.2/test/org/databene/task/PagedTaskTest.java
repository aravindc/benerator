/*
 * (c) Copyright 2007 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.task;

import junit.framework.TestCase;

/**
 * Created: 16.07.2007 20:02:03
 */
public class PagedTaskTest extends TestCase {

    public void testSingleInvocation() {
        checkRun(1,  1,  1,   1, 1, 1);
        checkRun(1, 10,  1,   1, 1, 1);
        checkRun(1,  1, 10,   1, 1, 1);
        checkRun(1, 10, 10,   1, 1, 1);
    }

    public void testSingleThreadedInvocation() {
        checkRun(10,  1,  1,   10, 10, 10);
        checkRun(10, 10,  1,    1, 10,  1);
    }

    public void testMultiThreadedInvocation() {
        checkRun(10,  1, 10,   10, 10, 10);
        checkRun(10, 10, 10,   10, 10, 10);
    }

    public void testMultiPagedInvocation() {
        checkRun(10,  5, 1,    2, 10,  2);
        checkRun(10,  5, 2,    4, 10,  4);
        checkRun(20,  5, 2,    8, 20,  8);
    }

    public void testNonThreadSafeTask() {
        checkNonThreadSafeTask(1,   1, 1, 1); // single threaded
        checkNonThreadSafeTask(10, 10, 1, 1); // single threaded, single-paged
        checkNonThreadSafeTask(10,  5, 1, 1); // single threaded, multi-paged

        checkNonThreadSafeTask(10, 10, 2, 3); // multi-threaded, single-paged
        checkNonThreadSafeTask(10,  5, 2, 5); // multi-threaded, multi-paged
    }

    public void checkNonThreadSafeTask(int totalInvocations, int pageSize, int threads, int expectedInstanceCount) {
        SingleThreadedTask.instanceCount = 0;
        SingleThreadedTask task = new SingleThreadedTask();
        PagedTask pagedTask = new PagedTask(task, totalInvocations, pageSize, threads);
        pagedTask.init(new TaskContext());
        pagedTask.run();
        pagedTask.destroy();
        assertEquals("Unexpected instanceCount", expectedInstanceCount, SingleThreadedTask.instanceCount);
    }

    private void checkRun(int totalInvocations, int pageSize, int threads,
                          int expectedInitCount, int expectedRunCount, int expectedDestroyCount) {
        CountTask countTask = new CountTask();
        PagedTask pagedTask = new PagedTask(countTask, totalInvocations, pageSize, threads);
        pagedTask.init(new TaskContext());
        pagedTask.run();
        pagedTask.destroy();
        assertEquals("Unexpected initCount", expectedInitCount, countTask.initCount);
        assertEquals("Unexpected runCount", expectedRunCount, countTask.runCount);
        assertEquals("Unexpected destroyCount", expectedDestroyCount, countTask.destroyCount);
    }
}
