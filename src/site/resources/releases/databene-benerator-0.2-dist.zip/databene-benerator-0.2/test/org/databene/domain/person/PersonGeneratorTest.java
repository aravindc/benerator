package org.databene.domain.person;

import junit.framework.TestCase;
import org.databene.generator.IllegalGeneratorStateException;
import org.databene.domain.address.Country;

import java.util.Locale;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 09.06.2006 22:14:08
 */
public class PersonGeneratorTest extends TestCase {

    public void test() throws IllegalGeneratorStateException {
        PersonGenerator generator = new PersonGenerator(Country.GERMANY, Locale.GERMANY);
        for (int i = 0; i < 10; i++) {
            System.out.println(generator.generate());
        }
    }
}
