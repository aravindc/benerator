/*
 * (c) Copyright 2006 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.generator.csv;

import org.databene.generator.Generator;
import org.databene.generator.IllegalGeneratorStateException;
import org.databene.generator.InvalidGeneratorSetupException;
import org.databene.generator.PropertyMessage;
import org.databene.document.csv.CSVTokenizer;
import org.databene.document.csv.CSVTokenType;
import org.databene.model.Converter;
import org.databene.model.ConversionException;
import org.databene.model.converter.NoOpConverter;

import java.io.IOException;
import java.io.Reader;

/**
 * Generates object by reading from CSV file cells
 * and using a Converter to parse the cell Strings into Objects.
 *
 * Created: 26.08.2006 18:52:08
 */
public class CSVCellImportGenerator<E> implements Generator<E> {

    /** The source url */
    private String url;

    /** The reader object used for input. It may implicitly result from the url or be set explicitly */
    private Reader reader;

    /** the converter to instantiate the target objects from a String representation */
    private Converter<String, E> converter;

    /** The tokenizer for CSV file access */
    private CSVTokenizer tokenizer;

    private boolean dirty;

    // constructors ----------------------------------------------------------------------------------------------------

    public CSVCellImportGenerator() {
        this((String)null);
    }

    /** Initializes the generator to read and return String values from the CSV file */
    public CSVCellImportGenerator(String url) {
        this(url, new NoOpConverter());
    }

    /**
     * Initializes the generator with the converter only.
     * The url still remains to be set.
     * @see #converter
     */
    public CSVCellImportGenerator(Converter<String, E> converter) {
        this((String)null, converter);
    }

    /**
     * Initializes the generator to read CSV cells from the url
     * and convert them to the target objects by the converter.
     * @param converter
     * @param url
     * @see #converter
     */
    public CSVCellImportGenerator(String url, Converter<String, E> converter) {
        this.converter = converter;
        this.url = url;
        this.reader = null;
        dirty = true;
    }

    public CSVCellImportGenerator(Reader reader, Converter<String, E> converter) {
        this.converter = converter;
        this.url = null;
        this.reader = reader;
        dirty = true;
    }

    // config properties -----------------------------------------------------------------------------------------------

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    // Generator implementation ----------------------------------------------------------------------------------------

    public void validate() {
        if (dirty) {
            if (converter == null)
                throw new InvalidGeneratorSetupException("converter", "null");
            if (url == null && reader == null)
                throw new InvalidGeneratorSetupException(
                        new PropertyMessage("url", "url or reader property must be set"),
                        new PropertyMessage("reader", "url or reader property must be set"));
            reset();
            dirty = false;
        }
    }

    /**
     * @see org.databene.generator.Generator#generate()
     */
    public E generate() {
        if (dirty)
            validate();
        if (tokenizer.ttype == CSVTokenType.EOF)
            throw new IllegalGeneratorStateException("Generator has finished");
        try {
            E result = converter.convert(tokenizer.cell);
            skipEOLs();
            if (tokenizer.ttype == CSVTokenType.EOF)
                close();
            return result;
        } catch (ConversionException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean available() {
        return tokenizer != null;
    }

    /**
     * @see org.databene.generator.Generator#close()
     */
    public void close() {
        try {
            if (tokenizer != null) {
                tokenizer.close();
                tokenizer = null;
            }
//            lastTokenType = null;
        } catch (IOException e) {
            throw new IllegalGeneratorStateException(e);
        }
    }

    /**
     * @see org.databene.generator.Generator#reset() ()
     */
    public void reset() {
        try {
            if (url != null)
                tokenizer = new CSVTokenizer(url);
            else
                tokenizer = new CSVTokenizer(reader);
            skipEOLs();
        } catch (IOException e) {
            throw new IllegalGeneratorStateException(e);
        }
    }

    // private helpers -------------------------------------------------------------------------------------------------

    private void skipEOLs() {
        try {
            do {
                tokenizer.ttype = tokenizer.next();
            } while (tokenizer.ttype == CSVTokenType.EOL);
        } catch (IOException e) {
            throw new IllegalGeneratorStateException(e);
        }
    }
}
