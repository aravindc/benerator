package org.databene.domain.person;

import java.util.Date;
import java.util.Calendar;

import org.databene.generator.primitive.DateGenerator;
import org.databene.generator.primitive.number.distribution.Sequence;
import org.databene.generator.IllegalGeneratorStateException;
import org.databene.generator.LightweightGenerator;
import org.databene.commons.TimeUtil;
import org.databene.commons.Period;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 13.06.2006 07:15:03
 */
public class BirthDateGenerator extends LightweightGenerator<Date> {

    private DateGenerator dateGenerator;

    public BirthDateGenerator(int minAgeYears, int maxAgeYears) {
        Date today = TimeUtil.today().getTime();
        Calendar min = TimeUtil.calendar(today);
        min.add(Calendar.YEAR, -maxAgeYears);
        Calendar max = TimeUtil.calendar(today);
        max.add(Calendar.YEAR, -minAgeYears);
        dateGenerator = new DateGenerator(min.getTime(), max.getTime(), Period.DAY.getMillis());
        dateGenerator.setDistribution(Sequence.RANDOM);
    }

    public Date generate() throws IllegalGeneratorStateException {
       return dateGenerator.generate();
    }
}
