package org.databene.region;

import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.Locale;

/**
 * Represents a geographical region.
 * Regions may form a composition structure from continents to multi-country regions, countries, states and so on.<br/>
 * <br/>
 * Created: 25.06.2006 22:28:04
 */
public abstract class Region {

    private static Map<String, Region> instances = new HashMap<String, Region>();
    private static Region defaultRegion = new BasicRegion(Locale.getDefault().getCountry());

    public static Region getInstance(String regionCode) {
        return instances.get(regionCode);
    }

    public static Region valueOf(String regionCode) {
        return getInstance(regionCode);
    }

    protected String code;

    public Region(String code) {
        this.code = code;
        instances.put(code, this);
    }

    public static Region getDefault() {
        return defaultRegion;
    }

    public String getCode() {
        return code;
    }

    public abstract boolean contains(Region region);

    public abstract Collection countries();

}
