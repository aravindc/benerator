/*
 * (c) Copyright 2006 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.generator.csv;

import org.databene.generator.Generator;
import org.databene.generator.IllegalGeneratorStateException;
import org.databene.generator.InvalidGeneratorSetupException;
import org.databene.document.csv.CSVLineIterator;

import java.io.*;

/**
 * Generates String arrays from CSV file rows.
 *
 * Created: 26.08.2006 16:16:04
 */
public class CSVLineImportGenerator implements Generator<String[]> {

    /** The url of the CSV source file */
    private String source;

    private char separator;

    private Reader reader;

    private boolean dirty;

    /** The parser used for parsing the CSV source */
    private CSVLineIterator iterator;

    // constructors ----------------------------------------------------------------------------------------------------

    public CSVLineImportGenerator() {
        this((String)null, ',');
    }

    public CSVLineImportGenerator(Reader reader, char separator) {
        this.reader = reader;
        this.separator = separator;
        this.dirty = true;
    }

    public CSVLineImportGenerator(String source, char separator) {
        this.source = source;
        this.separator = separator;
        this.dirty = true;
    }

    // config properties -----------------------------------------------------------------------------------------------

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
        this.dirty = false;
    }

    public void setReader(Reader reader) {
        this.reader = reader;
        this.dirty = false;
    }

    public char getSeparator() {
        return separator;
    }

    public void setSeparator(char separator) {
        this.separator = separator;
    }

    // Generator implementation ----------------------------------------------------------------------------------------

    public void validate() {
        if (source == null && reader == null)
            throw new InvalidGeneratorSetupException("No source URL or reader is set");
        if (dirty) {
            reset();
            dirty = false;
        }
    }

    /** @see org.databene.generator.Generator#generate() */
    public String[] generate() {
        if (dirty)
            validate();
        if (iterator == null)
            throw new IllegalGeneratorStateException("Generator is unavailable");
        String[] result = iterator.next();
        if (!iterator.hasNext())
            close();
        return result;
    }

    public boolean available() {
        if (dirty)
            validate();
        return iterator != null;
    }

    /** @see org.databene.generator.Generator#close() */
    public void close() {
        if (iterator != null) {
            try {
                iterator.close();
                iterator = null;
            } catch (IOException e) {
                throw new IllegalGeneratorStateException(e);
            }
        }
    }

    /** @see org.databene.generator.Generator#reset() */
    public void reset() {
        close();
        try {
            if (source != null)
                iterator = new CSVLineIterator(source, separator);
            else if (reader != null)
                iterator = new CSVLineIterator(reader, separator);
        } catch (IOException e) {
            throw new IllegalGeneratorStateException(e);
        }
    }

}
