package org.databene.domain.address;

import org.databene.generator.IllegalGeneratorStateException;
import org.databene.generator.LightweightGenerator;

import java.util.Locale;

/**
 * Creates Addresses.<br/>
 * <br/>
 * Created: 11.06.2006 08:07:40
 *
 * Generation order from dependencies: country -> city -> street -> housenumber -> zipCode
 */
public class AddressGenerator extends LightweightGenerator<Address> {

    private Country country;
    private Locale displayLocale;

    public AddressGenerator() {
        this(Country.getDefault());
    }

    public AddressGenerator(Country country) {
        this(country, Locale.getDefault());
    }

    public AddressGenerator(Country country, Locale locale) {
        this.country = country;
        this.displayLocale = locale;
    }

    public Address generate() throws IllegalGeneratorStateException {
        City city = country.generateCity();
        Street street = city.generateStreet();
        String[] data = street.generateHouseNumberWithZipCode();
        String houseNumber = data[0];
        String zipCode = data[1];
        PhoneNumber privatePhone = city.generatePhoneNumber();
        PhoneNumber officePhone = city.generatePhoneNumber();
        PhoneNumber mobilePhone = country.generateMobilePhoneNumber();
        PhoneNumber fax = city.generatePhoneNumber();
        return new Address(street.getName(), houseNumber, zipCode, city.getName(), country.getName(displayLocale), privatePhone, officePhone, mobilePhone, fax);
    }
}
