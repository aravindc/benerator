package org.databene.domain.person;

import org.databene.generator.LightweightGenerator;
import org.databene.generator.Generator;
import org.databene.generator.IllegalGeneratorStateException;
import org.databene.generator.factory.GeneratorFactory;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 09.06.2006 21:45:23
 */
public class GenderGenerator extends LightweightGenerator<Gender> {

    private Generator<Gender> gen;

    public GenderGenerator() {
        this.gen = GeneratorFactory.getSampleGenerator(Gender.MALE, Gender.FEMALE);
    }

    public Gender generate() throws IllegalGeneratorStateException {
        return gen.generate();
    }
}
