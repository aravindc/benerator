package org.databene.domain.person;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 09.06.2006 21:44:06
 */
public enum Gender {
    FEMALE, MALE
}
