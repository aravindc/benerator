/*
 * (c) Copyright 2006 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.generator.primitive.regex;

import org.databene.generator.LightweightGenerator;
import org.databene.generator.Generator;
import org.databene.generator.wrapper.AlternativeGenerator;
import org.databene.generator.wrapper.ConvertingGenerator;
import org.databene.generator.primitive.CharacterGenerator;
import org.databene.generator.primitive.number.adapter.IntegerGenerator;
import org.databene.regex.*;
import org.databene.model.converter.ToStringConverter;

/**
 * Creates a part of a regular expression which could be a CharSetPattern, a Group or an AlternativePattern.<br/>
 * <br/>
 * Created: 20.08.2006 08:52:04
 */
class RegexPartGenerator extends LightweightGenerator<String> {

    /** The generator specific for the pattern */
    private Generator<String> patternGenerator;

    /** A number generator for generating quanities */
    private IntegerGenerator quantityGenerator;

    /** Initializes the generator
     * @param part the regular expression part to match with the products
     * @param maxQuantity the maximum value to use for unlimited quantities
     */
    public RegexPartGenerator(RegexPart part, int maxQuantity) {
        SubPattern pattern = part.getPattern();
        if (pattern instanceof CharSetPattern)
            patternGenerator = new ConvertingGenerator<String,Character>(
                    new CharacterGenerator(((CharSetPattern)pattern).getCharSet()),
                    new ToStringConverter<Character>());
        else if (pattern instanceof Group)
            patternGenerator = new RegexStringGenerator(((Group)part.getPattern()).getRegex(), maxQuantity);
        else if (pattern instanceof AlternativePattern)
            patternGenerator = new AlternativeGenerator<String>(getRegexGenerators((AlternativePattern)pattern, maxQuantity));
        int min = part.getQuantifier().getMin();
        int max = part.getQuantifier().getMax();
        if (max == -1)
            max = Math.max(min, maxQuantity);
        quantityGenerator = new IntegerGenerator(min, max);
    }

    // Generator interface ---------------------------------------------------------------------------------------------

    /** Determines a quantity, invokes the pattern as many times and assembles the products to a String */
    public String generate() {
        StringBuffer buffer = new StringBuffer();
        int quantity = quantityGenerator.generate();
        for (int i = 0; i < quantity; i++)
            buffer.append(patternGenerator.generate());
        return buffer.toString();
    }

    // private helpers -------------------------------------------------------------------------------------------------

    /** creates an array of generators, of which each one will generate a pattern from the alternatives */
    private static RegexStringGenerator[] getRegexGenerators(AlternativePattern alternatives, int maxPartLength) {
        Regex[] regexes = alternatives.getPatterns();
        RegexStringGenerator[] sources = new RegexStringGenerator[regexes.length];
        for (int i = 0; i < regexes.length; i++)
            sources[i] = new RegexStringGenerator(regexes[i], maxPartLength);
        return sources;
    }

}
