/*
 * (c) Copyright 2006 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.generator.primitive.number.distribution;

import org.databene.commons.ConfigurationError;
import org.databene.commons.BeanUtil;

import java.util.Map;
import java.util.HashMap;
import java.util.Collection;

/**
 * Provides access to specific Sequence number Generators.<br/>
 * <br/>
 * Created: 11.09.2006 21:12:57
 */
public class Sequence implements Distribution {

    private static Map<String, Sequence> map = new HashMap<String, Sequence>();

    // predefined Sequences --------------------------------------------------------------------------------------------

    public static final Sequence RANDOM      = new Sequence("random", RandomDoubleGenerator.class, RandomLongGenerator.class);
    public static final Sequence SHUFFLE     = new Sequence("shuffle", ShuffleDoubleGenerator.class, ShuffleLongGenerator.class);
    public static final Sequence CUMULATED   = new Sequence("cumulated", CumulatedDoubleGenerator.class, CumulatedLongGenerator.class);
    public static final Sequence RANDOM_WALK = new Sequence("randomWalk", RandomWalkDoubleGenerator.class, RandomWalkLongGenerator.class);

    // attributes ------------------------------------------------------------------------------------------------------

    private String name;
    private Class<? extends AbstractLongGenerator> longGeneratorClass;
    private Class<? extends AbstractDoubleGenerator> doubleGeneratorClass;

    // factory methods -------------------------------------------------------------------------------------------------

    public Sequence(String name, Class<? extends AbstractDoubleGenerator> doubleGenerator) {
        this(name, doubleGenerator, LongFromDoubleGenerator.class);
    }

    public Sequence(String name, Class<? extends AbstractDoubleGenerator> doubleGenerator, Class<? extends AbstractLongGenerator> longGenerator) {
        this.name = name;
        this.longGeneratorClass = longGenerator;
        this.doubleGeneratorClass = doubleGenerator;
        if (map.get(name) != null)
            throw new ConfigurationError("Sequence defined twice: " + name);
        map.put(name, this);
    }

    public static Collection<Sequence> getInstances() {
        return map.values();
    }

    public static Sequence getInstance(String name) {
        return map.get(name);
    }

    // interface -------------------------------------------------------------------------------------------------------

    public String getName() {
        return name;
    }

    public AbstractLongGenerator createLongGenerator() {
        if (LongFromDoubleGenerator.class.equals(longGeneratorClass))
            return new LongFromDoubleGenerator(createDoubleGenerator());
        else
            return BeanUtil.newInstance(longGeneratorClass);
    }

    public AbstractDoubleGenerator createDoubleGenerator() {
        return BeanUtil.newInstance(doubleGeneratorClass);
    }

    // java.lang.Object overrides --------------------------------------------------------------------------------------

    public String toString() {
        return name;
    }
}
