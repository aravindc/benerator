package org.databene.domain.person;

import org.databene.generator.IllegalGeneratorStateException;
import org.databene.generator.LightweightGenerator;
import org.databene.generator.Generator;
import org.databene.region.RegionUtil;
import org.databene.region.Region;
import org.databene.generator.sample.CSVSampleGenerator;

/**
 * (c) Copyright 2006 by Volker Bergmann
 * Created: 09.06.2006 21:13:09
 */
public class GivenNameGenerator extends LightweightGenerator<String> {

    private Generator<String> gen;

    public GivenNameGenerator() {
        this(Region.getDefault(), Gender.MALE);
    }

    public GivenNameGenerator(Region region, Gender gender) {
        if (gender == Gender.FEMALE)
            gen = new CSVSampleGenerator<String>(RegionUtil.availableRegionUrl("org/databene/domain/person/givenName_female", region, ".csv"));
        else if (gender == Gender.MALE)
            gen = new CSVSampleGenerator<String>(RegionUtil.availableRegionUrl("org/databene/domain/person/givenName_male", region, ".csv"));
        else
            throw new IllegalArgumentException("Gender: " + gender);
    }

    public String generate() throws IllegalGeneratorStateException {
        return gen.generate();
    }

}
