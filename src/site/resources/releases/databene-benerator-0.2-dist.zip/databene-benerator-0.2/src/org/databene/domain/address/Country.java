/*
 * (c) Copyright 2007 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.domain.address;

import org.databene.generator.sample.SampleGenerator;
import org.databene.generator.Generator;
import org.databene.generator.primitive.regex.RegexStringGenerator;
import org.databene.region.Region;
import org.databene.region.BasicRegion;
import org.databene.commons.StringUtil;
import org.databene.commons.ConfigurationError;
import org.databene.commons.ArrayUtil;
import org.databene.commons.ArrayFormat;
import org.databene.document.csv.CSVLineIterator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;
import java.io.IOException;

/**
 * TODO.<br/>
 * <br/>
 * Created: 11.06.2006 08:15:37
 */
public class Country {

    private static final Log logger = LogFactory.getLog(Country.class);

    private static String FILE_NAME = "org/databene/domain/address/country.csv";

    private static Map<String, Country> instances = new HashMap<String, Country>(250);

    static {
        parseConfigFile();
    }

    public static final Country GERMANY = getInstance("DE");
    public static final Country AUSTRIA = getInstance("AT");
    public static final Country SWITZERLAND = getInstance("CH");
    public static final Country LIECHTENSTEIN = getInstance("LI");

    public static final Country BELGIUM = getInstance("BE");
    public static final Country NETHERLANDS = getInstance("NL");
    public static final Country LUXEMBURG = getInstance("LU");

    public static final Country ITALY = getInstance("IT");
    public static final Country FRANCE = getInstance("FR");
    public static final Country SPAIN = getInstance("ES");
    public static final Country PORTUGAL = getInstance("PT");
    public static final Country ANDORRA = getInstance("AD");

    public static final Country GREECE = getInstance("gr");

    public static final Country SLOWENIA = getInstance("SI");
    public static final Country CZECH_REPUBLIC = getInstance("CZ");
    public static final Country HUNGARY = getInstance("HR");
    public static final Country POLAND = getInstance("PL");
    public static final Country RUSSIA = getInstance("RU");
    public static final Country ROMANIA = getInstance("RO");
    public static final Country BULGARIA = getInstance("BG");
    public static final Country CROATIA = getInstance("HR");
    public static final Country BOSNIA_AND_HERZEGOVINA = getInstance("BA");
    public static final Country TURKEY = getInstance("TR");
    public static final Country ESTONIA = getInstance("EE");
    public static final Country LITHUANIA = getInstance("LT");
    public static final Country LATVIA = getInstance("LV");

    public static final Country UNITED_KINGDOM = getInstance("UK");
    public static final Country DENMARK = getInstance("DK");
    public static final Country SWEDEN = getInstance("SE");
    public static final Country NORWAY = getInstance("NO");
    public static final Country FINLAND = getInstance("FI");
    public static final Country IRELAND = getInstance("IE");
    public static final Country ICELAND = getInstance("IS");

    public static final Country USA = getInstance("US");
    public static final Country JAPAN = getInstance("JP");

    private static Country defaultCountry;

    static {
        defaultCountry = Country.getInstance(Locale.getDefault().getCountry().toLowerCase());
    }

    private static void parseConfigFile() {
        CSVLineIterator iterator = null;
        try {
            iterator = new CSVLineIterator(FILE_NAME);
            while (iterator.hasNext()) {
                String[] cells = iterator.next();
                if (cells.length > 0) {
                    String isoCode = cells[0];
                    String phoneCode = (cells.length > 1 ? cells[1] : null);
                    String[] mobilCodes = (cells.length > 2 ?
                            ArrayUtil.copyOfRange(cells, 2, cells.length - 2) : new String[0]);
                    new Country(isoCode, phoneCode, mobilCodes);
                }
            }
        } catch (IOException e) {
            throw new ConfigurationError("Country definition file could not be processed. ", e);
        } finally {
            try {
                if (iterator != null)
                    iterator.close();
            } catch (IOException e) {
                logger.error(e, e);
            }
        }
    }


    // TODO add constants
    // TODO configure from file

    private String isoCode;
    private Region region;
    private String phoneCode;
    private Locale displayLocale;
    private SampleGenerator<City> cityGenerator;
    private boolean valid;
    private Locale countryLocale;
    private Generator<String> mobilePreCodeGenerator;
    private Generator<String> mobileLocalCodeGenerator;


    public Country(String isoCode, String phoneCode, String ... mobileCodes) {
        this(isoCode, phoneCode, null, mobileCodes);
    }

    public Country(String isoCode, String phoneCode, Locale displayLocale, String ... mobileCodes) {
        this.isoCode = isoCode;
        this.phoneCode = phoneCode;
        this.displayLocale = displayLocale;
        this.countryLocale = new Locale("xx", isoCode);
        this.region = new BasicRegion(isoCode);
        this.mobilePreCodeGenerator = new SampleGenerator<String>(mobileCodes);
        this.mobileLocalCodeGenerator = new RegexStringGenerator("[1-9]\\d{6,7}");
        valid = false;
        instances.put(isoCode, this);
    }

    public String getName() {
        return getName(displayLocale);
    }

    public String getName(Locale displayLocale) {
        return countryLocale.getDisplayCountry(displayLocale);
    }

    public City generateCity() {
        if (!valid)
            validate();
//        return generateState().generateCity();
        City city;
        do {
            city = cityGenerator.generate();
        } while (StringUtil.isEmpty(city.getPhoneCode())); // TODO the database contains cities with unknown phone codes
        return city;
    }

    public PhoneNumber generateMobilePhoneNumber() {
        String preCode = mobilePreCodeGenerator.generate();
        String localCode = mobileLocalCodeGenerator.generate();
        return new PhoneNumber(phoneCode, preCode, localCode, true);
    }

    public void setDisplayLocale(Locale displayLocale) {
        this.displayLocale = displayLocale;
    }

    private void validate() {
        cityGenerator = new SampleGenerator<City>();
        addFromFile("org/databene/domain/address/city_" + isoCode + ".csv");
        valid = true;
    }

    private void addFromFile(String filename) {
        try {
            CSVLineIterator parser = new CSVLineIterator(filename, ';');
            String[] tokens;
            HashMap<String, City> cities = new HashMap<String, City>();
            parser.next(); // skip first line
            while ((tokens = parser.next()) != null) {
                if (tokens.length < 5)
                    continue;
                List<String> list = new ArrayList<String>();
                list.add(tokens[2]);
                City newCity = new City(this, tokens[0], tokens[1], list, tokens[3], tokens[4]);
                City city = cities.get(newCity.toString());
                if (city == null) {
                    cities.put(newCity.toString(), newCity);
                } else {
                    city.addZipCode(tokens[2]);
                }
            }
            parser.close();
            for (City city : cities.values())
                cityGenerator.addValue(city);
        } catch (IOException e) {
            throw new RuntimeException(e); // TODO
        }
    }

    public String getIsoCode() {
        return isoCode;
    }

    public String getPhoneCode() {
        return phoneCode;
    }

    public Region getRegion() {
        return region;
    }

    public String toString() {
        return getName();
    }

    public static Collection<Country> getInstances() {
        return instances.values();
    }

    public static Country getInstance(String isoCode) {
        Country country = instances.get(isoCode.toUpperCase());
        if (country == null)
            country = new Country(isoCode, "UNKNOWN"); // TODO
        return country;
    }

    public static Country getDefault() {
        return defaultCountry;
    }
}
