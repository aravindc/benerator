/*
 * (c) Copyright 2006 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.generator.wrapper;

import org.databene.generator.Generator;
import org.databene.model.Converter;
import org.databene.model.converter.ParseFormatConverter;
import org.databene.model.converter.FormatFormatConverter;

import java.text.Format;
import java.text.DateFormat;

/**
 * A ConvertingGenerator implementation that uses a java.text.Format object
 * to convert a String into an object or vice versa.<br/>
 * <br/>
 * Created: 18.06.2006 11:59:05
 */
public class FormatGenerator<T,S> extends ConvertingGenerator<T,S> {

    /** flag to use when converting Objects to Strings */
    public static final int FORMAT = 0;

    /** flag to use when converting Strings to Objects */
    public static final int PARSE = 1;

    /**
     * Initializtes the generator
     * @param source the source generator
     * @param format the format to apply
     * @param direction PARSE for using the format's parseObject() method in conversion, FORMAT for using format()
     */
    public FormatGenerator(Generator<S> source, Format format, int direction) {
        super(source, getConverter(format, direction));
    }

    /**
     * Instantiates the appropriate converter for the desired conversion direction.
     * @param format the format to apply
     * @param direction PARSE for using the format's parseObject() method in conversion, FORMAT for using format()
     * @return a FormatFormatConverter for formatting objects or a ParseFormatConverter for parsing Strings.
     */
    private static Converter getConverter(Format format, int direction) {
        if (direction == 0)
            return new FormatFormatConverter(format);
        else
            return new ParseFormatConverter(format);
    }

    public static <S> FormatGenerator<String,S> createFormattingGenerator(Generator<S> source, DateFormat format) {
        return new FormatGenerator<String,S>(source, format, FORMAT);
    }

    public static <S> FormatGenerator<S,String> createParsingGenerator(Generator<String> source, DateFormat format) {
        return new FormatGenerator<S,String>(source, format, PARSE);
    }
}
