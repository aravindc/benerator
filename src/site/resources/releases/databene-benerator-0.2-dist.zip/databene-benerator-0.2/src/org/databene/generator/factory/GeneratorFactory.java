/*
 * (c) Copyright 2006 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License.
 *
 * For redistributing this software or a derivative work under a license other
 * than the GPL-compatible Free Software License as defined by the Free
 * Software Foundation or approved by OSI, you must first obtain a commercial
 * license to this software product from Volker Bergmann.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.generator.factory;

import org.databene.generator.sample.SampleGenerator;
import org.databene.generator.sample.Sample;
import org.databene.generator.sample.CSVSampleGenerator;
import org.databene.generator.sample.ConstantGenerator;
import org.databene.generator.primitive.regex.RegexStringGenerator;
import org.databene.generator.csv.CSVCellImportGenerator;
import org.databene.generator.csv.CSVLineImportGenerator;
import org.databene.generator.primitive.BooleanGenerator;
import org.databene.generator.primitive.CharacterGenerator;
import org.databene.generator.primitive.DateGenerator;
import org.databene.generator.Generator;
import org.databene.generator.ValidatingGeneratorProxy;
import org.databene.generator.primitive.number.distribution.Distribution;
import org.databene.generator.primitive.number.adapter.IntegralNumberGenerator;
import org.databene.generator.primitive.number.adapter.BigDecimalGenerator;
import org.databene.generator.primitive.number.adapter.FloatingPointNumberGenerator;
import org.databene.generator.wrapper.*;
import org.databene.commons.LocaleUtil;
import org.databene.model.converter.NumberToNumberConverter;
import org.databene.model.converter.ParseFormatConverter;
import org.databene.model.converter.NoOpConverter;
import org.databene.model.Converter;
import org.databene.model.validator.StringLengthValidator;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Provides factory methods for generators.<br/>
 * <br/>
 * Created: 23.08.2006 21:44:27
 */
public class GeneratorFactory {

    // Singleton related stuff -----------------------------------------------------------------------------------------

    /** Private constructor that prevents the user from multiple instantiantion */
    private GeneratorFactory() {
    }

    /** The static attribute for keeping the only instance of this class */
    private static GeneratorFactory instance;


    /**
     * The instance factory and accessor method
     * @deprecated use the static methods of the class itself
     */
    public static GeneratorFactory getInstance() {
        if (instance == null)
            instance = new GeneratorFactory();
        return instance;
    }

    // boolean generator -----------------------------------------------------------------------------------------------

    /**
     * Creates a generator for boolean values of a trueQuots [0-1] and a nullQuota [0-1]
     * @param trueQuota a value from 0 to 1, indicating the quota of true values to generate among the non-null values
     * @param nullQuota a value from 0 to 1, indicating the quota of true values to generate
     * @return a Boolean generator of the desired characteristics
     */
    public static Generator<Boolean> getBooleanGenerator(double trueQuota, double nullQuota) {
        BooleanGenerator realGenerator = new BooleanGenerator(trueQuota);
        return wrap(realGenerator, nullQuota);
    }

    // number generators -----------------------------------------------------------------------------------------------

    /**
     * Creates a generator for numbers.
     * @param type the number type, e.g. java.lang.Integer
     * @param min the minimum number to generate
     * @param max the maximum number to generate
     * @param precision the resolution to use in number generation.
     * @param distribution The Sequence of WeightFunction to use for generation
     * @param nullQuota the quota of null values to generate [0..1].
     * @return a Number generator of the desired characteristics
     */
    public static <T extends Number> Generator<T> getNumberGenerator(
            Class<T> type, T min, T max, T precision,
            Distribution distribution, double nullQuota) {
        return getNumberGenerator(type, min, max, precision, distribution,
                NumberToNumberConverter.convert(1, type), NumberToNumberConverter.convert(1, type),
                nullQuota);
    }

    /**
     * Creates a generator for numbers.
     * @param type the number type, e.g. java.lang.Integer
     * @param min the minimum number to generate
     * @param max the maximum number to generate
     * @param precision the resolution to use in number generation.
     * @param distribution The Sequence of WeightFunction to use for generation
     * @param variation1 parameter #1 for Sequence setup which is individual to the Sequence type
     * @param variation2 parameter #2 for Sequence setup which is individual to the Sequence type
     * @param nullQuota the quota of null values to generate [0..1].
     * @return a Number generator of the desired characteristics
     */
    public static <T extends Number> Generator<T> getNumberGenerator(
            Class<T> type, T min, T max, T precision,
            Distribution distribution, T variation1, T variation2,
            double nullQuota) {
        if (type == null)
            throw new IllegalArgumentException("Number type is null");
        Generator<T> source;
        if (Integer.class.equals(type) || Long.class.equals(type) || Byte.class.equals(type) || Short.class.equals(type) || BigInteger.class.equals(type))
            source = new IntegralNumberGenerator<T>(type, min, max, precision, distribution, variation1, variation2);
        else if (Double.class.equals(type) || Float.class.equals(type))
            source = (Generator<T>) new FloatingPointNumberGenerator(type, min, max, precision, distribution, variation1, variation2);
        else if (BigDecimal.class.equals(type))
            source = (Generator<T>) new BigDecimalGenerator(
                    (BigDecimal) min, (BigDecimal) max, (BigDecimal) precision, distribution,
                    (BigDecimal) variation1, (BigDecimal) variation2);
        else
            throw new UnsupportedOperationException("Number type not supported: " + type.getName());
        return wrap(source, nullQuota);
    }

    // sample source ------------------------------------------------------------------------------------------------

    /**
     * Creates a generator that reads cell Strings from a CSV file and converts them into objects by a converter
     * @param url The URL or filename to read the data from
     * @param converter the converter to use for representing the file entries
     * @return a Generator that creates instances of the parameterized type T.
     */
    public static <T> Generator<T> getSampleGenerator(String url, Converter<String, T> converter) {
        if (converter == null)
            converter = new NoOpConverter();
        return new CSVSampleGenerator<T>(url, converter);
    }

    /**
     * Creates a Generator that chooses from a set of values with equal weights.
     * @param values A collection of values to choose from
     * @return a generator that selects from the listed sample values
     */
    public static <T> Generator<T> getSampleGenerator(Collection<T> values) {
        return new SampleGenerator<T>(values);
    }

    /**
     * Creates a Generator that chooses from an array of values with equal weights.
     * @param values An array of values to choose from
     * @return a generator that selects from the listed sample values
     */
    public static <T> Generator<T> getSampleGenerator(T ... values) {
        return new SampleGenerator<T>(values);
    }

    /**
     * Creates a generator that chooses from a set of samples, using an individual weight for each sample.
     * @param samples A collection of sample values
     * @return a generator of the desired characteristics
     */
    public static <T> Generator<T> getWeightedSampleGenerator(Collection<Sample<T>> samples) {
        SampleGenerator<T> generator = new SampleGenerator<T>();
        generator.setSamples(samples);
        return generator;
    }

    /**
     * Creates a generator that chooses from a set of samples, using an individual weight for each sample.
     * @param samples A collection of sample values
     * @return a generator of the desired characteristics
     */
    public static <T> Generator<T> getWeightedSampleGenerator(Sample<T> ... samples) {
        SampleGenerator<T> generator = new SampleGenerator<T>();
        generator.setSamples(samples);
        return generator;
    }

    // date source --------------------------------------------------------------------------------------------------

    /**
     * Creates a Date generator that generates random dates.
     * @param min The earliest Date to generate
     * @param max The latest Date to generate
     * @param precision the time resolution of dates in milliseconds
     * @param distribution the Sequence or WeightFunction to use
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    public static Generator<Date> getDateGenerator(
            Date min, Date max, long precision, Distribution distribution, double nullQuota) {
        DateGenerator generator = new DateGenerator(min, max, precision, distribution);
        return wrap(generator, nullQuota);
    }

    /**
     * Creates a date generator that generates date entries from a CSV file.
     * @param url the url of the CSV file.
     * @param pattern the pattern to use for parsing the CSV cells
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    public static Generator<Date> getDateGenerator(String url, String pattern, double nullQuota) {
        DateFormat format = new SimpleDateFormat(pattern);
        Converter<String, Date> converter = new ParseFormatConverter<Date>(format);
        CSVSampleGenerator<Date> generator = new CSVSampleGenerator<Date>(url, converter);
        return wrap(generator, nullQuota);
    }

    // text generators -------------------------------------------------------------------------------------------------

    /**
     * Creates a generator that produces characters of a locale.
     * @param locale the locale to choose the characters from
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    public static Generator<Character> getCharacterGenerator(Locale locale, double nullQuota) {
        CharacterGenerator generator = new CharacterGenerator(LocaleUtil.letters(locale));
        return wrap(generator, nullQuota);
    }

    /**
     * Creates a Character generator that creates characters of a locale which match a regular expresseion.
     * @param pattern the regular expression that indicates the available range of values
     * @param locale the locale to use for '\w' evaluation
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    public static Generator<Character> getCharacterGenerator(String pattern, Locale locale, double nullQuota) {
        CharacterGenerator generator = new CharacterGenerator(pattern, locale);
        return wrap(generator, nullQuota);
    }

    /**
     * Creates a character generator that creates values from a collection of charcters
     * @param characters the set of characters to choose from
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    public static Generator<Character> getCharacterGenerator(Collection<Character> characters, double nullQuota) {
        return wrap(new CharacterGenerator(characters), nullQuota);
    }

    /**
     * Creates a character generator that creates values from a set of charcters
     * @param characters the set of characters to choose from
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    public static Generator<Character> getCharacterGenerator(double nullQuota, Character ... characters) {
        return wrap(new CharacterGenerator(Arrays.asList(characters)), nullQuota);
    }

    /**
     * Creates a generator that produces Strings which match a regular expression in a locale
     * @param pattern the regular expression
     * @param minLength the minimum length of the products
     * @param maxLength the maximum length of the products
     * @param locale the locale to use for '\w' expressions
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    public static Generator<String> getRegexStringGenerator(
            String pattern, int minLength, int maxLength, Locale locale, double nullQuota) {
        Generator<String> generator = new RegexStringGenerator(pattern, locale, maxLength);
        generator = new ValidatingGeneratorProxy<String, StringLengthValidator>(
                generator, new StringLengthValidator(minLength, maxLength));
        return wrap(generator, nullQuota);
    }

    // formatting generators -------------------------------------------------------------------------------------------

    /**
     * Creates a generator that accepts products from a source generator
     * and converts them to target products by the converter
     * @param source the source generator
     * @param converter the converter to apply to the products of the source generator
     * @return a generator of the desired characteristics
     */
    public static <T, S> Generator<T> getConvertingGenerator(Generator<S> source, Converter<S, T> converter) {
        return new ConvertingGenerator<T, S>(source, converter);
    }

    /**
     * Creates a generator that generates messages by reading the products of several source generators and
     * combining them by a Java MessageFormat.
     * @param pattern the MessageFormat pattern
     * @param minLength the minimum length of the generated value
     * @param maxLength the maximum length of the generated value
     * @param sources the source generators of which to assemble the products
     * @return a generator of the desired characteristics
     * @see java.text.MessageFormat
     */
    public static Generator<String> getMessageGenerator(
            String pattern, int minLength, int maxLength, Generator ... sources) {
        return new MessageGenerator(pattern, minLength, maxLength, sources);
    }

    // collection generators -------------------------------------------------------------------------------------------

    /**
     * Creates a generator that combines several products of a source generator to a collection.
     * @param collectionType the type of collection to create, e.g. java.util.List or java.util.TreeSet
     * @param source the generator that provides the collection items
     * @param minLength the minimum collection length
     * @param maxLength the maximum collection length
     * @param lengthDistribution a Sequence or WeightFunction for the distribution of collection lengths
     * @return a generator of the desired characteristics
     */
    public static <C extends Collection<I>, I> Generator<C> getCollectionGenerator(
            Class<C> collectionType, Generator<I> source, int minLength, int maxLength,
            Distribution lengthDistribution) {
        return new CollectionGenerator<C, I>(collectionType, source, minLength, maxLength, lengthDistribution);
    }

    /**
     * Creates a generator that combines several products of a source generator to a collection.
     * @param source the generator that provides the array items
     * @param type the type of the array
     * @param minLength the minimum array length
     * @param maxLength the maximum array length
     * @param lengthDistribution a Sequence or WeightFunction for the distribution of array lengths
     * @return a generator of the desired characteristics
     */
    public static <T> Generator<T[]> getArrayGenerator(
            Generator<T> source, Class<T> type, int minLength, int maxLength, Distribution lengthDistribution) {
        return new SimpleArrayGenerator<T>(source, type, minLength, maxLength, lengthDistribution);
    }

    /**
     * Creates a generator that reads products of an array of generators and combines them to an array.
     * @param sources the source generators
     * @return a generator of the desired characteristics
     */
    public static Generator<Object[]> getArrayGenerator(Generator ... sources) {
        return new CompositeArrayGenerator(sources);
    }

    // wrappers --------------------------------------------------------------------------------------------------------

    /**
     * Creates a generator that returns a constant value.
     * @param value the value to return
     * @return a generator that returns a constant value.
     */
    public static <T> Generator<T> getConstantGenerator(T value) {
        return new ConstantGenerator<T>(value);
    }

    // source generators -----------------------------------------------------------------------------------------------

    /**
     * Creates a generator that iterates through a CSV file.
     * @param url the URL of the CSV file
     * @param iteration the iteration mode
     * @return a generator of the desired characteristics
     */
    public static Generator<String> getCSVCellGenerator(String url, Iteration iteration) {
        return new IteratingGenerator<String>(new CSVCellImportGenerator<String>(url), iteration);
    }

    /**
     * creates a generator that imports lines from a CSV files and returns them as String arrays.
     * @param url
     * @param iteration
     * @return a generator of the desired characteristics
     */
    public static Generator<String[]> getCSVLineGenerator(String url, Iteration iteration, char separator) {
        return new IteratingGenerator<String[]>(new CSVLineImportGenerator(url, separator), iteration);
    }

    // helpers ---------------------------------------------------------------------------------------------------------

    /**
     * Wraps a generator and forwards its products on generate(), but inserts a quota of null values.
     * @param source the generator to use for input
     * @param nullQuota the quota of null values to generate
     * @return a generator of the desired characteristics
     */
    static <T> Generator<T> wrap(final Generator<T> source, double nullQuota) {
        Generator<T> generator = source;
        if (nullQuota > 0)
            generator = new NullableGenerator<T>(source, (float)nullQuota);
        return generator;
    }
}
