package org.databene.domain.address;

import org.databene.region.Region;
import org.databene.generator.Generator;
import org.databene.generator.primitive.regex.RegexStringGenerator;

import java.util.List;
/**
 * TODO.<br/>
 * <br/>
 * Created: 11.06.2006 08:19:23
 */
public class City {

    // Ort;Zusatz;Plz;Vorwahl;Bundesland
    private Country country;
    private String name;
    private String addition;
    private List<String> zipCodes;
    private String phoneCode;
    private String state;
    private int inhabitants;

    private StreetNameGenerator streetNameGenerator;
    private Generator<String> localPhoneNumberGenerator;

    public City(Country country, String name, String addition, List<String> zipCodes, String phoneCode, String state) {
        this.country = country;
        this.name = name;
        this.addition = addition;
        this.zipCodes = zipCodes;
        // TODO the following is a bug fix for the german city csv file: it contains leading zeros for the phone code
        this.phoneCode = (country.getIsoCode().equals("DE") && phoneCode.startsWith("0") ? phoneCode.substring(1) : phoneCode);
        this.state = state;
        streetNameGenerator = StreetNameGenerator.getInstance(Region.getInstance(country.getIsoCode()));
        int localPhoneCodeLength = 9 - phoneCode.length();
        localPhoneNumberGenerator = new RegexStringGenerator("[1-9]\\d{" + (localPhoneCodeLength - 1) + '}');
    }

    public String getAddition() {
        return addition;
    }

    public void setAddition(String addition) {
        this.addition = addition;
    }

    public List<String> getZipCodes() {
        return zipCodes;
    }

    public void setZipCodes(List<String> zipCodes) {
        this.zipCodes = zipCodes;
    }

    public void addZipCode(String zipCode) {
        zipCodes.add(zipCode);
    }

    public String getPhoneCode() {
        return phoneCode;
    }

    public void setPhoneCode(String phoneCode) {
        this.phoneCode = phoneCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public int getInhabitants() {
        return inhabitants;
    }

    public void setInhabitants(int inhabitants) {
        this.inhabitants = inhabitants;
    }

    public Street generateStreet() {
        String streetName = streetNameGenerator.generate();
        return new Street(this, streetName);
    }

    public PhoneNumber generatePhoneNumber() {
        String localCode = localPhoneNumberGenerator.generate();
        return new PhoneNumber(country.getPhoneCode(), this.phoneCode, localCode, false);
    }

    // java.lang.Object overrides --------------------------------------------------------------------------------------

    public String toString() {
        return name + (addition.length() > 0 && Character.isLetter(addition.charAt(0)) ? " " : "") + addition;
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        final City city = (City) o;
        if (addition != null ? !addition.equals(city.addition) : city.addition != null)
            return false;
        return name.equals(city.name);

    }

    public int hashCode() {
        int result;
        result = name.hashCode();
        result = 29 * result + (addition != null ? addition.hashCode() : 0);
        return result;
    }

}
